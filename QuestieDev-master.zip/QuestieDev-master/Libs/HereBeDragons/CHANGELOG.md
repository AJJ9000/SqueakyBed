# Lib: HereBeDragons

## [2.02-release](https://github.com/Nevcairiel/HereBeDragons/tree/2.02-release) (2019-07-24)
[Full Changelog](https://github.com/Nevcairiel/HereBeDragons/compare/2.01-release...2.02-release)

- Update TOC  
- Add World Map Data for Classic  
- Preliminary WoW Classic support  
- Add travis-ci support  
- Add LuaCheck and EditorConfig, and clean sources to pass  
- Fill in the map list by iterating over all known maps, in addition to processing the child tree  
