---
name: Feature Request
about: You're thinking about something to improve Questie? Let us know what feature you would like to see in Questie!
labels: "feature request"
---

## Description
<!-- Explain in detail what the kind of changes or additional functionalities you suggest. -->
